# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.7.18)
# Database: Bus
# Generation Time: 2017-12-17 10:08:17 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table booked_seats
# ------------------------------------------------------------

DROP TABLE IF EXISTS `booked_seats`;

CREATE TABLE `booked_seats` (
  `booked_seats_id` int(4) NOT NULL AUTO_INCREMENT,
  `user_id` int(4) NOT NULL,
  `seat_no` int(2) NOT NULL,
  `bus_id` int(4) NOT NULL,
  PRIMARY KEY (`booked_seats_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table booking
# ------------------------------------------------------------

DROP TABLE IF EXISTS `booking`;

CREATE TABLE `booking` (
  `booking_id` int(4) NOT NULL AUTO_INCREMENT,
  `user_id` int(4) NOT NULL,
  `route_id` int(4) NOT NULL,
  `bus_id` int(4) NOT NULL,
  `no_of_seats_booked` int(2) NOT NULL,
  `source` varchar(25) NOT NULL DEFAULT '',
  `destination` varchar(25) NOT NULL DEFAULT '',
  `bus_type` varchar(25) NOT NULL DEFAULT '',
  `total_amount` int(5) NOT NULL,
  `booking_date` date NOT NULL,
  PRIMARY KEY (`booking_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table bus
# ------------------------------------------------------------

DROP TABLE IF EXISTS `bus`;

CREATE TABLE `bus` (
  `bus_id` int(4) NOT NULL AUTO_INCREMENT,
  `bus_name` varchar(25) NOT NULL DEFAULT '',
  `bus_type` varchar(25) NOT NULL DEFAULT '',
  `no_of_seats` int(2) NOT NULL,
  `contact_no` double(10,0) NOT NULL,
  `bus_start_time` float NOT NULL,
  `route_id` int(4) NOT NULL,
  PRIMARY KEY (`bus_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1237 DEFAULT CHARSET=latin1;

LOCK TABLES `bus` WRITE;
/*!40000 ALTER TABLE `bus` DISABLE KEYS */;

INSERT INTO `bus` (`bus_id`, `bus_name`, `bus_type`, `no_of_seats`, `contact_no`, `bus_start_time`, `route_id`)
VALUES
	(1234,'cal-ban','express',44,9946440299,15.45,1111),
	(1235,'cal-mys','ac',42,9846352944,9.45,1112),
	(1236,'cal-ban','superfast',44,9946440299,12.3,1111);

/*!40000 ALTER TABLE `bus` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table bus_and_route
# ------------------------------------------------------------

DROP TABLE IF EXISTS `bus_and_route`;

CREATE TABLE `bus_and_route` (
  `b_r_id` int(4) NOT NULL AUTO_INCREMENT,
  `bus_id` int(4) NOT NULL,
  `route_id` int(4) NOT NULL,
  PRIMARY KEY (`b_r_id`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=latin1;

LOCK TABLES `bus_and_route` WRITE;
/*!40000 ALTER TABLE `bus_and_route` DISABLE KEYS */;

INSERT INTO `bus_and_route` (`b_r_id`, `bus_id`, `route_id`)
VALUES
	(101,1234,1111),
	(102,1235,1112);

/*!40000 ALTER TABLE `bus_and_route` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table payment
# ------------------------------------------------------------

DROP TABLE IF EXISTS `payment`;

CREATE TABLE `payment` (
  `payment_id` int(4) NOT NULL AUTO_INCREMENT,
  `booking_id` int(4) NOT NULL,
  `amount` int(5) NOT NULL,
  `booking_date` date NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table rate
# ------------------------------------------------------------

DROP TABLE IF EXISTS `rate`;

CREATE TABLE `rate` (
  `rate_id` int(4) NOT NULL AUTO_INCREMENT,
  `bus_type` varchar(25) NOT NULL DEFAULT '',
  `rate_per_km` int(3) NOT NULL,
  `basic_rate` int(4) NOT NULL,
  PRIMARY KEY (`rate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table route
# ------------------------------------------------------------

DROP TABLE IF EXISTS `route`;

CREATE TABLE `route` (
  `route_id` int(4) NOT NULL AUTO_INCREMENT,
  `route_name` varchar(25) NOT NULL DEFAULT '',
  `route_source` varchar(25) NOT NULL DEFAULT '',
  `route_destination` varchar(25) NOT NULL DEFAULT '',
  `route_distance` int(3) NOT NULL,
  PRIMARY KEY (`route_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1113 DEFAULT CHARSET=latin1;

LOCK TABLES `route` WRITE;
/*!40000 ALTER TABLE `route` DISABLE KEYS */;

INSERT INTO `route` (`route_id`, `route_name`, `route_source`, `route_destination`, `route_distance`)
VALUES
	(1111,'calicut-bangalore','calicut','bangalore',350),
	(1112,'caliut-mysore','calicut','mysore',275);

/*!40000 ALTER TABLE `route` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table seat
# ------------------------------------------------------------

DROP TABLE IF EXISTS `seat`;

CREATE TABLE `seat` (
  `status_id` int(4) NOT NULL AUTO_INCREMENT,
  `bus_id` int(4) NOT NULL,
  `seat_no` int(2) NOT NULL,
  `seat_status` varchar(10) NOT NULL DEFAULT '',
  `booked_value` int(2) DEFAULT '0',
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=latin1;

LOCK TABLES `seat` WRITE;
/*!40000 ALTER TABLE `seat` DISABLE KEYS */;

INSERT INTO `seat` (`status_id`, `bus_id`, `seat_no`, `seat_status`, `booked_value`)
VALUES
	(101,1234,1,'available',0),
	(102,1234,2,'booked',2),
	(103,1234,3,'available',0),
	(104,1234,4,'available',0),
	(105,1234,5,'booked',3),
	(106,1235,1,'available',0),
	(107,1235,2,'booked',0);

/*!40000 ALTER TABLE `seat` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table stops
# ------------------------------------------------------------

DROP TABLE IF EXISTS `stops`;

CREATE TABLE `stops` (
  `stop_id` int(4) NOT NULL AUTO_INCREMENT,
  `route_id` int(4) NOT NULL,
  `stop_name` varchar(25) NOT NULL DEFAULT '',
  `stop_value` int(2) NOT NULL,
  `distance_from_origin` int(3) NOT NULL,
  `time_from_origin` float NOT NULL,
  PRIMARY KEY (`stop_id`)
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=latin1;

LOCK TABLES `stops` WRITE;
/*!40000 ALTER TABLE `stops` DISABLE KEYS */;

INSERT INTO `stops` (`stop_id`, `route_id`, `stop_name`, `stop_value`, `distance_from_origin`, `time_from_origin`)
VALUES
	(100,1111,'calicut',1,0,0),
	(101,1111,'thamarassery',2,15,1),
	(102,1111,'sulthan bathery',3,90,2.3),
	(103,1111,'mysore',4,200,3.5),
	(104,1111,'bangalore',5,350,7.4),
	(105,1112,'calicut',1,0,0),
	(106,1112,'thamarassery',2,15,1),
	(107,1112,'sulthan bathery',3,90,2.3),
	(108,1112,'mysore',4,200,3.5),
	(109,1113,'bangalore',1,0,0),
	(110,1113,'mysore',2,0,0),
	(111,1113,'sulthan bathery',3,0,0),
	(112,1113,'thamarassery',4,0,0),
	(113,1113,'calicut',5,0,0);

/*!40000 ALTER TABLE `stops` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table user
# ------------------------------------------------------------

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL DEFAULT '',
  `email` varchar(25) NOT NULL DEFAULT '',
  `user_contact` double(10,0) NOT NULL,
  `username` varchar(25) NOT NULL DEFAULT '',
  `password` varchar(25) NOT NULL DEFAULT '',
  `gender` char(1) NOT NULL DEFAULT '',
  `age` int(3) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
